import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class PatientsService {

  constructor(private http:HttpClient) { }

  getAllpatient(){
    let url="http://localhost:8080/personnes";
    return this.http.get(url);
  }


  getAllMedecin(){
    let url="http://localhost:8080/medecins";
    return this.http.get(url);
  }

}
